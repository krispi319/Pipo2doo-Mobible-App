package com.mwm.sdk.basekit.log;

public interface Logger {

    /**
     * Log a debug message.
     *
     * @param tag     a tag associated with the message.
     * @param message the message to log.
     */
    void logDebug(String tag, String message);

    /**
     * Log a warning message.
     *
     * @param tag     a tag associated with the message.
     * @param message the message to log.
     */
    void logWarning(String tag, String message);

    /**
     * Log an error message.
     *
     * @param tag     a tag associated with the message.
     * @param message the message to log.
     */
    void logError(String tag, String message);

    /**
     * Log an error message.
     *
     * @param tag     a tag associated wit the message.
     * @param message the message to log.
     * @param tr      a {@link Throwable} associated with the error.
     */
    void logError(String tag, String message, Throwable tr);
}
