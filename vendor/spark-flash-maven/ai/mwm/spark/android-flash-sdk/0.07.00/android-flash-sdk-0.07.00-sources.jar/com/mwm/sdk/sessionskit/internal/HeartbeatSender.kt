package com.mwm.sdk.sessionskit.internal

import androidx.annotation.WorkerThread

/** HeartbeatSender is responsible of sending a heartbeat. */
internal interface HeartbeatSender {

    /** Send a heartbeat for a given [SessionType]. */
    @WorkerThread fun send(sessionType: SessionType)
}
