package com.mwm.sdk.sessionskit.internal

import android.os.Handler
import com.mwm.sdk.basekit.log.Logger
import kotlin.properties.Delegates

/**
 * A HeartbeatEmitter implementation for Android.
 *
 * Internally, this implementation is a state machine. It can have three states:
 * - Alive: a heartbeat will be emitted every X seconds.
 * - Alive but dying: a heartbeat will still be emitted, but after X seconds it will transition to
 *   the dead states.
 * - Dead: no heartbeat will be emitter.
 *
 * <code>
 *
 *      State diagram:
 *                                 --> emits a heartbeat directly.
 *                                /
 *      [Dead] ---> request start ---> [Alive]
 *
 * ----------------> [Alive] -----------------------> request stop ----> [Alive but dying] | | <---
 * every X seconds, emits a heartbeat <---
 *
 *                                                  ------> request start ----> [Alive]
 *                                                 /
 *    ---------------->  [Alive but dying] -----------------------> after Y seconds ----> [Dead]
 *    |                                            |
 *     <--- every X seconds, emits a heartbeat <---
 *
 * </code>
 */
internal class HeartbeatEmitterAndroid(
    private val frequencyInMillis: Long,
    private val deathDelayInMillis: Long,
    private val workerHandler: Handler,
    private val logger: Logger,
    private val sessionType: SessionType,
) : HeartbeatEmitter {

    private enum class Status {
        DEAD,
        ALIVE,
        ALIVE_BUT_DYING,
    }

    private val listeners = mutableListOf<HeartbeatEmitter.Listener>()
    private val emitHeartbeatJob = createHeartbeatJob(sessionType)
    private val requestStartJob = createRequestStartJob()
    private val requestStopJob = createRequestStopJob()
    private var pendingDeathJob = createPendingDeathJob()

    private var status: Status by
        Delegates.observable(Status.DEAD) { _, old, new ->
            logger.logDebug(
                Const.LOG_TAG,
                "HeartbeatEmitterAndroid#$sessionType | status changed from $old to $new",
            )
        }

    override fun requestStart() {
        workerHandler.post(requestStartJob)
    }

    override fun requestStop() {
        workerHandler.post(requestStopJob)
    }

    override fun addListener(listener: HeartbeatEmitter.Listener) {
        synchronized(listeners) {
            if (listeners.contains(listener)) {
                return
            }

            listeners.add(listener)
        }
    }

    override fun removeListener(listener: HeartbeatEmitter.Listener) {
        synchronized(listeners) { listeners.remove(listener) }
    }

    // MUST be called from one of the runnable posted on worker handler
    private fun bringToLife() {
        ensureCurrentStatus(Status.DEAD)

        status = Status.ALIVE
        emitHeartbeatJob.run()
    }

    // MUST be called from one of the runnable posted on worker handler
    private fun keepAlive() {
        ensureCurrentStatus(Status.ALIVE_BUT_DYING)

        cancelPendingDeath()
        status = Status.ALIVE
    }

    // MUST be called from one of the runnable posted on worker handler
    private fun scheduleDeath() {
        ensureCurrentStatus(Status.ALIVE)

        status = Status.ALIVE_BUT_DYING
        workerHandler.postDelayed(pendingDeathJob, deathDelayInMillis)
    }

    // MUST be called from one of the runnable posted on worker handler
    private fun cancelPendingDeath() {
        workerHandler.removeCallbacks(pendingDeathJob)
    }

    // MUST be called from one of the runnable posted on worker handler
    private fun ensureCurrentStatus(expectedStatus: Status) {
        if (status != expectedStatus) {
            throw IllegalStateException(
                "HeartbeatEmitterAndroid#$sessionType | Was expecting status $expectedStatus but was in status $status"
            )
        }
    }

    // MUST be posted on worker handler
    private fun createRequestStartJob(): Runnable {
        return Runnable {
            when (status) {
                Status.ALIVE -> return@Runnable
                Status.ALIVE_BUT_DYING -> keepAlive()
                Status.DEAD -> bringToLife()
            }
        }
    }

    // MUST be posted on worker handler
    private fun createRequestStopJob(): Runnable {
        return Runnable {
            when (status) {
                Status.DEAD,
                Status.ALIVE_BUT_DYING -> return@Runnable
                Status.ALIVE -> scheduleDeath()
            }
        }
    }

    // MUST be posted on worker handler
    private fun createPendingDeathJob(): Runnable {
        return Runnable {
            ensureCurrentStatus(Status.ALIVE_BUT_DYING)
            workerHandler.removeCallbacks(emitHeartbeatJob)
            status = Status.DEAD
        }
    }

    // MUST be posted on worker handler
    private fun createHeartbeatJob(sessionType: SessionType): Runnable {
        return object : Runnable {
            override fun run() {
                if (status == Status.DEAD) {
                    throw IllegalStateException(
                        "HeartbeatEmitterAndroid#$sessionType | Was about to emit an heartbeat but status is $status"
                    )
                }

                // Emit a hearth beat
                emitHeartbeat(sessionType)

                // Schedule next heartbeat
                workerHandler.postDelayed(this, frequencyInMillis)
            }
        }
    }

    private fun emitHeartbeat(sessionType: SessionType) {
        synchronized(listeners) {
            for (listener in listeners) {
                listener.onHeartbeatEmitted(sessionType)
            }
        }
    }
}
