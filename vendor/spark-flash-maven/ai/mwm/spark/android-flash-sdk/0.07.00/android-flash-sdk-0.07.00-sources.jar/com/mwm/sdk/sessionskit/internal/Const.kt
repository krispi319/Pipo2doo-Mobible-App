package com.mwm.sdk.sessionskit.internal

internal object Const {
    const val LOG_TAG = "sessions-kit"
}
