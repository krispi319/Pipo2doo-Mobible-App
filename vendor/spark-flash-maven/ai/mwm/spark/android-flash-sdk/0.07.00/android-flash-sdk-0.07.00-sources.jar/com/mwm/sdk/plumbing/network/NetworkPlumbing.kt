package com.mwm.sdk.plumbing.network

import okhttp3.OkHttpClient

@Suppress("unused")
object NetworkPlumbing {

    /** Get the current shared [OkHttpClient]. */
    @Suppress("MemberVisibilityCanBePrivate")
    var sharedOkHttpClient: OkHttpClient = OkHttpClient()
        private set

    /**
     * Install a new [OkHttpClient] that will replaced the current one.
     *
     * This is an advanced feature, mostly for debug purpose.
     */
    fun installSharedOkHttpClient(okHttpClient: OkHttpClient) {
        sharedOkHttpClient = okHttpClient
    }
}
