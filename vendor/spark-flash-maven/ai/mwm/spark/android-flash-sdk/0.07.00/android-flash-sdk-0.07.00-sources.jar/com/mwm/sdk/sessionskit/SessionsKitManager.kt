package com.mwm.sdk.sessionskit

import androidx.annotation.AnyThread

interface SessionsKitManager {

    /**
     * Start an emitter for a given [sessionKind]. This emitter will works like the "base" emitter
     * except that it can be stopped manually.
     *
     * Note: it's safe to call this method from any thread.
     *
     * @param sessionKind : the kind of the desired emitter
     */
    @AnyThread fun startEmitter(sessionKind: String)

    /**
     * Stop an emitter for a given [sessionKind]
     *
     * Note: it's safe to call this method from any thread.
     *
     * @param sessionKind : the kind of the desired emitter
     */
    @AnyThread fun stopEmitter(sessionKind: String)
}
