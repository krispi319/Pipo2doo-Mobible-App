/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.mwm.sdk.basekit;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.mwm.sdk.basekit";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String BASE_KIT_VERSION = "3.02.00";
}
