package com.mwm.sdk.basekit.installation;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import java.util.UUID;

public class InstallationIdProvider {

    private static final String SHARED_PREFERENCES_NAME = "installation_id";
    private static final String INSTALLATION_ID_KEY = "INSTALLATION_ID_KEY";

    private final String installationId;

    public InstallationIdProvider(Application app) {
        SharedPreferences sharedPreferences = app.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
        String persistedInstallationId = sharedPreferences.getString(INSTALLATION_ID_KEY, null);

        if (persistedInstallationId != null) {
            installationId = persistedInstallationId;
        } else {
            installationId = generateInstallationId();
            persistInstallationId(sharedPreferences, installationId);
        }
    }

    @NonNull
    public String getInstallationId() {
        return installationId;
    }

    @SuppressLint("ApplySharedPref")
    private static void persistInstallationId(SharedPreferences sharedPreferences, String installationId) {
        sharedPreferences.edit().putString(INSTALLATION_ID_KEY, installationId).commit();
    }

    private static String generateInstallationId() {
        return UUID.randomUUID().toString();
    }

}
