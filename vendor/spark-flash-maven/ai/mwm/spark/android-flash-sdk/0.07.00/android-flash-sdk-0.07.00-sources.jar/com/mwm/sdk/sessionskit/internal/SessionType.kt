package com.mwm.sdk.sessionskit.internal

internal sealed interface SessionType {

    /**
     * Represent a "foreground session": a period of time during which the user engages with the
     * application in foreground.
     */
    data object Foreground : SessionType

    /**
     * Represent a "custom session": a period of time during which the user engages with a task of
     * the specified kind.
     */
    data class Custom(val kind: String) : SessionType
}
