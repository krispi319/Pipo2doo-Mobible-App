package com.mwm.sdk.basekit.device_type;

/**
 * Define the type of mobile services that are targeted by our kits.
 */
public enum MobileService {

    /**
     * Kits target google play services.
     */
    GMS,

    /**
     * Kits target huawei services
     */
    HMS
}
