package com.mwm.sdk.basekit.log;

import com.mwm.sdk.basekit.Precondition;

public final class Log {

    private static Logger sLogger = new SilentLogger();

    public static void install(Logger logger) {
        Precondition.checkNotNull(logger);
        sLogger = logger;
    }

    /**
     * Get the currently installed {@link Logger}
     * <b>Note:</b> for testing purpose only.
     *
     * @return the currently installed {@link Logger}
     */
    public static Logger getCurrentLogger() {
        return sLogger;
    }

    /**
     * Log a debug message.
     *
     * @param tag     a tag associated with the message.
     * @param message the message to log.
     */
    public static void d(String tag, String message) {
        sLogger.logDebug(tag, message);
    }

    /**
     * Log a warning message.
     *
     * @param tag     a tag associated with the message.
     * @param message the message to log.
     */
    public static void w(String tag, String message) {
        sLogger.logWarning(tag, message);
    }

    /**
     * Log an error message.
     *
     * @param tag     a tag associated with the message.
     * @param message the message to log.
     */
    public static void e(String tag, String message) {
        sLogger.logError(tag, message);
    }

    /**
     * Log an error message.
     *
     * @param tag     a tag associated wit the message.
     * @param message the message to log.
     * @param tr      a {@link Throwable} associated with the error.
     */
    public static void e(String tag, String message, Throwable tr) {
        sLogger.logError(tag, message, tr);
    }

    private Log() {
        //no instance
    }
}

