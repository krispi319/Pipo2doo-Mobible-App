package com.mwm.sdk.sessionskit

import com.mwm.sdk.basekit.BaseConfig

data class SessionsKitConfig
@JvmOverloads
constructor(
    val baseConfig: BaseConfig,
    val frequencyInMillis: Long = DEFAULT_FREQUENCY_IN_MILLIS,
    val deathDelayInMillis: Long = DEFAULT_DEATH_DELAY_IN_MILLIS,
    val hostNames: HostNames = defaultHostNames,
    val httpAuthorization: String? = null,
) {

    /**
     * Host names for sessions-kit backend.
     *
     * @property dev - dev environment
     * @property prod - production environment
     */
    data class HostNames(val dev: String, val prod: String)

    companion object {
        const val DEFAULT_FREQUENCY_IN_MILLIS = 10_000L
        const val DEFAULT_DEATH_DELAY_IN_MILLIS = 2_000L
        private val defaultHostNames =
            HostNames(
                dev = "https://dev-dot-api-dot-mwm-sessions.ew.r.appspot.com",
                prod = "https://mwmsessions.com",
            )
    }
}
