package com.mwm.sdk.sessionskit

import android.os.Handler
import android.os.HandlerThread
import com.mwm.sdk.basekit.log.AndroidLogger
import com.mwm.sdk.basekit.log.Logger
import com.mwm.sdk.basekit.log.SilentLogger
import com.mwm.sdk.plumbing.network.NetworkPlumbing
import com.mwm.sdk.sessionskit.internal.HeartbeatSender
import com.mwm.sdk.sessionskit.internal.HeartbeatSenderHttp
import com.mwm.sdk.sessionskit.internal.HeartbeatSenderLog
import com.mwm.sdk.sessionskit.internal.HeartbeatSenderWrapper
import com.mwm.sdk.sessionskit.internal.SessionKitManagerImpl

class SessionsKitModule(private val sessionsKitConfig: SessionsKitConfig) {

    private val sharedLogger = createLogger()
    private val sharedWorkerThread = createWorkerHandler()
    private val sharedHeartbeatSender = createHeartbeatSender()
    private val sessionsKitManager =
        SessionKitManagerImpl(
            sessionsKitConfig,
            sharedHeartbeatSender,
            sharedWorkerThread,
            sharedLogger,
        )

    fun getSessionsManager(): SessionsKitManager = sessionsKitManager

    private fun createHeartbeatSender(): HeartbeatSender {
        val baseConfig = sessionsKitConfig.baseConfig
        val hostNames = sessionsKitConfig.hostNames
        val hostName =
            when (baseConfig.isDebug()) {
                true -> hostNames.dev
                false -> hostNames.prod
            }
        val httpSender =
            HeartbeatSenderHttp(
                hostName = hostName,
                httpAuthorization = sessionsKitConfig.httpAuthorization,
                baseConfig = baseConfig,
                okHttpClient = NetworkPlumbing.sharedOkHttpClient,
                logger = sharedLogger,
            )

        return if (baseConfig.isDebug()) {
            val logSender = HeartbeatSenderLog(sharedLogger)
            val senders = listOf(logSender, httpSender)
            HeartbeatSenderWrapper(senders)
        } else {
            httpSender
        }
    }

    private fun createLogger(): Logger {
        return if (sessionsKitConfig.baseConfig.isDebug()) {
            AndroidLogger(true)
        } else {
            SilentLogger()
        }
    }

    private fun createWorkerHandler(): Handler {
        val workerThread = HandlerThread("sessions-thread").apply { start() }
        return Handler(workerThread.looper)
    }
}
