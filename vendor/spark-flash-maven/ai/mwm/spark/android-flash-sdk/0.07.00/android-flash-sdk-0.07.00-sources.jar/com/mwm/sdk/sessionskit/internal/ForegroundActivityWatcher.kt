package com.mwm.sdk.sessionskit.internal

import android.app.Activity
import android.app.Application
import android.os.Bundle
import java.lang.ref.WeakReference

/**
 * A class responsible of watching foreground activities.
 *
 * Internally it uses a heartbeat emitter and sender to send heartbeat as long as at least one
 * activity is in foreground.
 */
internal class ForegroundActivityWatcher(
    app: Application,
    private val heartbeatSender: HeartbeatSender,
    private val heartbeatEmitter: HeartbeatEmitter,
) {

    init {
        val heartbeatEmitterListener = createHeartbeatEmitterListener()
        heartbeatEmitter.addListener(heartbeatEmitterListener)

        val lifecycleCallbacks = createActivityLifecycleCallbacks()
        app.registerActivityLifecycleCallbacks(lifecycleCallbacks)
    }

    private val foregroundActivities = mutableListOf<WeakReference<Activity>>()

    private fun onActivityResumed(activity: Activity) {
        addForegroundActivity(activity)

        if (foregroundActivities.isNotEmpty()) {
            heartbeatEmitter.requestStart()
        }
    }

    private fun onActivityPaused(activity: Activity) {
        removeForegroundActivity(activity)

        if (foregroundActivities.isEmpty()) {
            heartbeatEmitter.requestStop()
        }
    }

    private fun addForegroundActivity(activity: Activity) {
        cleanWeakActivities()

        // Ensure that the activity is not in the list already
        for (candidate in foregroundActivities) {
            if (candidate.get() == activity) {
                return
            }
        }

        foregroundActivities.add(WeakReference(activity))
    }

    private fun removeForegroundActivity(activity: Activity) {
        cleanWeakActivities()

        val iterator = foregroundActivities.iterator()
        while (iterator.hasNext()) {
            val weakActivity = iterator.next()

            if (weakActivity.get() == activity) {
                iterator.remove()
            }
        }
    }

    /**
     * Clean any null weak activities.
     *
     * This is more a "security" code. If for any reason, a weak activity is still in the foreground
     * activity list, but not longer points to a valid activity, we should remove it.
     */
    private fun cleanWeakActivities() {
        val iterator = foregroundActivities.iterator()
        while (iterator.hasNext()) {
            val weakActivity = iterator.next()

            if (weakActivity.get() == null) {
                iterator.remove()
            }
        }
    }

    private fun createHeartbeatEmitterListener(): HeartbeatEmitter.Listener {
        return object : HeartbeatEmitter.Listener {
            override fun onHeartbeatEmitted(sessionType: SessionType) {
                heartbeatSender.send(sessionType)
            }
        }
    }

    private fun createActivityLifecycleCallbacks(): Application.ActivityLifecycleCallbacks {
        return object : Application.ActivityLifecycleCallbacks {

            override fun onActivityResumed(activity: Activity) {
                this@ForegroundActivityWatcher.onActivityResumed(activity)
            }

            override fun onActivityPaused(activity: Activity) {
                this@ForegroundActivityWatcher.onActivityPaused(activity)
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                // Nothing to do
            }

            override fun onActivityStarted(activity: Activity) {
                // Nothing to do
            }

            override fun onActivityStopped(activity: Activity) {
                // Nothing to do
            }

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
                // Nothing to do
            }

            override fun onActivityDestroyed(activity: Activity) {
                // Nothing to do
            }
        }
    }
}
