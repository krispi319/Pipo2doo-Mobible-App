package com.mwm.sdk.basekit

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import com.mwm.sdk.basekit.device_type.MobileService
import com.mwm.sdk.basekit.installation.InstallationIdProvider
import com.mwm.sdk.basekit.store_distribution.StoreDistribution
import java.util.Locale

class BaseConfig
private constructor(
    private val app: Application,
    private val gcpId: String,
    private val appId: String,
    private val appToken: String,
    private val installationId: String,
    private val mobileService: MobileService,
    private val debug: Boolean,
    private val packageInfo: PackageInfo? = getPackageInfo(app),
    private val appVersionName: String = computeAppVersionName(packageInfo),
    private val appVersionCode: Long = computeAppVersionCode(packageInfo),
    private val sdkVersionName: String = BuildConfig.BASE_KIT_VERSION,
    private val storeDistribution: StoreDistribution,
) {

    fun getApp(): Application = app

    fun getGcpId(): String = gcpId

    fun getAppId(): String = appId

    fun getAppToken(): String = appToken

    fun getInstallationId(): String = installationId

    fun getMobileService(): MobileService = mobileService

    fun isDebug(): Boolean = debug

    fun getPackageInfo(): PackageInfo? = packageInfo

    fun getAppVersionName(): String = appVersionName

    fun getAppVersionCode(): Long = appVersionCode

    fun getSdkVersionName(): String = sdkVersionName

    /**
     * Get the brand of the store where the app is published. Attention, do not confuse the store
     * distribution with the services used inside the app.
     */
    fun getStoreDistribution(): StoreDistribution = storeDistribution

    fun getCurrentCountry(): Country {
        val locale = Locale.getDefault()
        return when (locale.country.uppercase(Locale.ROOT)) {
            "CN" -> Country.CHINA
            else -> Country.OTHER
        }
    }

    enum class Country {
        CHINA,
        OTHER,
    }

    companion object {

        /**
         * Create a [BaseConfig] that should be used to initialize the other kits.
         *
         * @param app an [Application].
         * @param gcpId the gcp id.
         * @param appId the app id.
         * @param appToken the app token.
         * @param debug true if it's a debug configuration, false otherwise.
         * @return a newly created [BaseConfig].
         */
        @Deprecated(
            message = "Use the create method with {@link StoreDistribution}.",
            ReplaceWith(
                "create(app, gcpId, appId, appToken, MobileService.GMS, StoreDistribution.GOOGLE, debug)"
            ),
        )
        @JvmStatic
        fun create(
            app: Application,
            gcpId: String,
            appId: String,
            appToken: String,
            debug: Boolean,
        ): BaseConfig =
            create(
                app = app,
                gcpId = gcpId,
                appId = appId,
                appToken = appToken,
                mobileService = MobileService.GMS,
                storeDistribution = StoreDistribution.GOOGLE,
                debug = debug,
            )

        /**
         * Create a [BaseConfig] that should be used to initialize the other kits.
         *
         * @param app an [Application].
         * @param gcpId the gcp id.
         * @param appId the app id.
         * @param appToken the app token.
         * @param mobileService the mobile service.
         * @param storeDistribution The brand of the store where the app is published. Attention, do
         *   not confuse the store distribution with the services used inside the app (it's not
         *   related to PlayServices).
         * @param debug true if it's a debug configuration, false otherwise.
         * @return a newly created [BaseConfig].
         */
        @JvmStatic
        fun create(
            app: Application,
            gcpId: String,
            appId: String,
            appToken: String,
            mobileService: MobileService,
            storeDistribution: StoreDistribution,
            debug: Boolean,
        ): BaseConfig =
            BaseConfig(
                app = app,
                gcpId = gcpId,
                appId = appId,
                appToken = appToken,
                installationId = InstallationIdProvider(app).installationId,
                mobileService = mobileService,
                storeDistribution = storeDistribution,
                debug = debug,
            )

        private fun getPackageInfo(context: Context): PackageInfo? =
            try {
                val packageManager = context.packageManager
                val packageName = context.packageName
                packageManager.getPackageInfo(packageName, 0)
            } catch (e: PackageManager.NameNotFoundException) {
                logException("Impossible to getPackageInfo. packageName: ${context.packageName}", e)
                null
            }

        private fun computeAppVersionName(packageInfo: PackageInfo?): String =
            if (packageInfo == null) {
                "invalid-version"
            } else {
                packageInfo.versionName ?: "invalid-version"
            }

        @Suppress("DEPRECATION")
        @SuppressLint("NewApi")
        private fun computeAppVersionCode(packageInfo: PackageInfo?): Long =
            when {
                packageInfo == null -> 0
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.P -> packageInfo.longVersionCode
                else -> packageInfo.versionCode.toLong()
            }

        private fun logException(message: String, e: Exception) {
            Log.e("BaseConfig", message, e)
        }
    }
}
