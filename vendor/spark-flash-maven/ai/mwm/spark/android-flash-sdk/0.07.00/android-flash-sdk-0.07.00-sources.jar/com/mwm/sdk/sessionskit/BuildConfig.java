/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.mwm.sdk.sessionskit;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.mwm.sdk.sessionskit";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String SESSIONS_KIT_VERSION = "android-4.02.00";
}
