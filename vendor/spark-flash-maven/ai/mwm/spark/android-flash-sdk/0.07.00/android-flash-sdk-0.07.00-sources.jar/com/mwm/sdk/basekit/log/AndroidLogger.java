package com.mwm.sdk.basekit.log;

public class AndroidLogger implements Logger {

    private final boolean debug;

    public AndroidLogger(boolean debug) {
        this.debug = debug;
    }

    @Override
    public void logDebug(String tag, String message) {
        if (!debug) return;

        android.util.Log.d(tag, message);
    }

    @Override
    public void logWarning(String tag, String message) {
        android.util.Log.w(tag, message);
    }

    @Override
    public void logError(String tag, String message) {
        android.util.Log.e(tag, message);
    }

    @Override
    public void logError(String tag, String message, Throwable tr) {
        android.util.Log.e(tag, message, tr);
    }
}

