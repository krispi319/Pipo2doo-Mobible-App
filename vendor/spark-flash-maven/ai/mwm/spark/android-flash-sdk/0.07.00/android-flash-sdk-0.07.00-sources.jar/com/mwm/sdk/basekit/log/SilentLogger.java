package com.mwm.sdk.basekit.log;

public class SilentLogger implements Logger {

    @Override
    public void logDebug(String tag, String message) {

    }

    @Override
    public void logWarning(String tag, String message) {

    }

    @Override
    public void logError(String tag, String message) {

    }

    @Override
    public void logError(String tag, String message, Throwable tr) {

    }
}
