package com.mwm.sdk.sessionskit.internal

import androidx.annotation.AnyThread
import androidx.annotation.WorkerThread

/** A HeartbeatEmitter is responsible of emitting heartbeats. */
internal interface HeartbeatEmitter {

    /**
     * Request the emitter to start emitting heartbeats.
     *
     * Note: it's safe to call this method multiple times, even if the emitter is "already started".
     */
    @AnyThread fun requestStart()

    /**
     * Request the emitter to stop emitting heartbeats.
     *
     * Note: it's safe to call this method multiple times, event if the emitter is "already
     * stopped".
     *
     * Note: heartbeats can still be emitted after this method has been called. The implementation
     * decides when it will effectively stop emitting heartbeats.
     */
    @AnyThread fun requestStop()

    /**
     * Add a listener.
     *
     * @param listener: the listener to add.
     */
    @AnyThread fun addListener(listener: Listener)

    /**
     * Remove a listener.
     *
     * @param listener: the listener to remove.
     */
    @AnyThread fun removeListener(listener: Listener)

    /** An interface for listening to heartbeat emission. */
    interface Listener {

        /** Called when a heartbeat has just been emitted for a given [SessionType] */
        @WorkerThread fun onHeartbeatEmitted(sessionType: SessionType)
    }
}
