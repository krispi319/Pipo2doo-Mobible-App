package com.mwm.sdk.basekit.store_distribution;

/**
 * The brand of the store where the app is published.
 * <p>
 * Attention, do not confuse the store distribution with the services used inside the app.
 */
public enum StoreDistribution {

    /**
     * Distribute to the Google Play Store
     */
    GOOGLE,

    /**
     * Distribute to the Huawei AppGallery
     */
    HUAWEI
}
