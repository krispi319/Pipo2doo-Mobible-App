package com.mwm.sdk.sessionskit.internal

import android.os.Handler
import androidx.annotation.AnyThread
import com.mwm.sdk.basekit.log.Logger
import com.mwm.sdk.sessionskit.SessionsKitConfig
import com.mwm.sdk.sessionskit.SessionsKitManager

internal class SessionKitManagerImpl(
    private val sessionsKitConfig: SessionsKitConfig,
    private val heartbeatSender: HeartbeatSender,
    private val workerHandler: Handler,
    private val logger: Logger,
) : SessionsKitManager {

    @Suppress("unused")
    private val foregroundActivityWatcher =
        ForegroundActivityWatcher(
            sessionsKitConfig.baseConfig.getApp(),
            heartbeatSender,
            createHeartbeatEmitter(SessionType.Foreground),
        )
    private val sessionKindToCustomHeartbeat = mutableMapOf<String, CustomHeartbeat>()

    @AnyThread
    override fun startEmitter(sessionKind: String) {
        synchronized(sessionKindToCustomHeartbeat) {
            sessionKindToCustomHeartbeat
                .getOrPut(sessionKind) { createCustomHeartbeat(sessionKind) }
                .start()
        }
    }

    @AnyThread
    override fun stopEmitter(sessionKind: String) {
        synchronized(sessionKindToCustomHeartbeat) {
            sessionKindToCustomHeartbeat.remove(sessionKind)?.stop()
        }
    }

    private fun createCustomHeartbeat(sessionKind: String): CustomHeartbeat {
        val emitter = createHeartbeatEmitter(SessionType.Custom(sessionKind))

        val customHeartbeat =
            CustomHeartbeat(heartbeatEmitter = emitter, heartbeatSender = heartbeatSender)

        return customHeartbeat
    }

    private fun createHeartbeatEmitter(sessionType: SessionType): HeartbeatEmitter {
        return HeartbeatEmitterAndroid(
            sessionsKitConfig.frequencyInMillis,
            sessionsKitConfig.deathDelayInMillis,
            workerHandler,
            logger,
            sessionType,
        )
    }

    private class CustomHeartbeat(
        private val heartbeatEmitter: HeartbeatEmitter,
        heartbeatSender: HeartbeatSender,
    ) {
        private val listener: HeartbeatEmitter.Listener

        init {
            listener = createHeartbeatEmitterListener(heartbeatSender)
        }

        @AnyThread
        fun start() {
            synchronized(this) {
                heartbeatEmitter.addListener(listener)
                heartbeatEmitter.requestStart()
            }
        }

        @AnyThread
        fun stop() {
            synchronized(this) {
                heartbeatEmitter.requestStop()
                heartbeatEmitter.removeListener(listener)
            }
        }

        private fun createHeartbeatEmitterListener(
            sender: HeartbeatSender
        ): HeartbeatEmitter.Listener {
            return object : HeartbeatEmitter.Listener {
                override fun onHeartbeatEmitted(sessionType: SessionType) {
                    sender.send(sessionType)
                }
            }
        }
    }
}
