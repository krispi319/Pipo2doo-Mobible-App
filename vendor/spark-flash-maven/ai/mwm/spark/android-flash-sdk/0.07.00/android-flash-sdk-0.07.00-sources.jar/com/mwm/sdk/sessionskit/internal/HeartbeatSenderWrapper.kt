package com.mwm.sdk.sessionskit.internal

/** A wrapper of multiple senders. */
internal class HeartbeatSenderWrapper(private val senders: List<HeartbeatSender>) :
    HeartbeatSender {
    override fun send(sessionType: SessionType) {
        for (sender in senders) {
            sender.send(sessionType)
        }
    }
}
