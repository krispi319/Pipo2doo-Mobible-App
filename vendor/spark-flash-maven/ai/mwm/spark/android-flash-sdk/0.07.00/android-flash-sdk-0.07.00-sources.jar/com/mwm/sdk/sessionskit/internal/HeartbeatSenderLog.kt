package com.mwm.sdk.sessionskit.internal

import com.mwm.sdk.basekit.log.Logger

/** "Debug" implementation of HeartbeatSender that simply logs a message. */
internal class HeartbeatSenderLog(private val logger: Logger) : HeartbeatSender {

    override fun send(sessionType: SessionType) {
        val logString =
            when (sessionType) {
                is SessionType.Foreground -> "HeartbeatSenderLog#send(foreground)"
                is SessionType.Custom -> "HeartbeatSenderLog#send(custom(${sessionType.kind}))"
            }

        logger.logDebug(Const.LOG_TAG, logString)
    }
}
