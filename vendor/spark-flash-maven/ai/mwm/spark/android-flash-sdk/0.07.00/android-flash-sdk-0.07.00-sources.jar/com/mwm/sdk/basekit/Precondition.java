package com.mwm.sdk.basekit;

public final class Precondition {

    /**
     * Ensures that an object reference is not null, with an error message.
     *
     * @param object the {@link Object} to check.
     * @throws NullPointerException if object if null.
     */
    public static void checkNotNull(Object object) {
        if (object == null) {
            throw new NullPointerException("Object can not be null");
        }
    }

    private Precondition() {
        //no instance
    }

}
