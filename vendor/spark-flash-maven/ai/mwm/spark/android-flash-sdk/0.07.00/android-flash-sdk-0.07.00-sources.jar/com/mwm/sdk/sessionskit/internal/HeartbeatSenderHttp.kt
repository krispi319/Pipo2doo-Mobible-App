package com.mwm.sdk.sessionskit.internal

import android.os.Build
import androidx.annotation.WorkerThread
import com.mwm.sdk.basekit.BaseConfig
import com.mwm.sdk.basekit.log.Logger
import com.mwm.sdk.sessionskit.BuildConfig
import com.mwm.sdk.sessionskit.R
import java.io.IOException
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttp
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response

/**
 * A naive heartbeat sender implementation that pings our server in a "fire and forget" way.
 *
 * Note: not handling offline / errors is a design choice for now.
 */
internal class HeartbeatSenderHttp(
    private val hostName: String,
    private val httpAuthorization: String?,
    private val baseConfig: BaseConfig,
    private val okHttpClient: OkHttpClient,
    private val logger: Logger,
) : HeartbeatSender {

    private val httpCallback = createHttpCallback()

    @WorkerThread
    override fun send(sessionType: SessionType) {
        // Even if we are called on a worker thread, we are still using the asynchronous
        // API enqueue so that the caller thread does not wait for the network call.
        // This method is called from the thread that emits all the ping: blocking this
        // caller thread during network calls would result in time drift.
        val request = createNewHeartbeatRequest(sessionType)
        val call = okHttpClient.newCall(request)
        call.enqueue(httpCallback)
    }

    private fun createNewHeartbeatRequest(sessionType: SessionType): Request {
        val url = getPingUrl(sessionType)

        return Request.Builder()
            .url(url)
            .post("".toRequestBody())
            .addHeader(HEADER_USER_AGENT, createUserAgent())
            .addHeader(HEADER_INSTALLATION_ID, baseConfig.getInstallationId())
            .addHeader(HEADER_SERVER_APP_KEY, baseConfig.getAppId())
            .addHeader(HEADER_DEVICE_TYPE, "android")
            .addHeader(HEADER_APP_VERSION, baseConfig.getAppVersionName())
            .addHeader(HEADER_SDK_VERSION, BuildConfig.SESSIONS_KIT_VERSION)
            .addHeader(HEADER_OS_NAME, "Android ${Build.VERSION.RELEASE}")
            .addHeader(HEADER_SCREEN_DENSITY, getScreenDensity())
            .apply {
                if (httpAuthorization != null) {
                    addHeader("Authorization", httpAuthorization)
                }
            }
            .build()
    }

    private fun getPingUrl(sessionType: SessionType): String {
        return when (sessionType) {
            is SessionType.Foreground -> "$hostName/$URL_PATH_PING"
            is SessionType.Custom -> "$hostName/$URL_PATH_PING/${sessionType.kind}"
        }
    }

    private fun createHttpCallback(): Callback {
        return object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                logger.logDebug(
                    Const.LOG_TAG,
                    "HeartbeatSenderHttp failure ${call.request()} with error $e",
                )
            }

            override fun onResponse(call: Call, response: Response) {
                logger.logDebug(
                    Const.LOG_TAG,
                    "HeartbeatSenderHttp response ${call.request()} with $response",
                )
            }
        }
    }

    private fun createUserAgent(): String {
        // Custom User Agent
        // Trying to follow the guidelines of Mozilla
        // Example of firefox user agent: Mozilla/5.0 Gecko/20100101 Firefox/47.0
        val okHttpUserAgent = "okhttp/${OkHttp.VERSION}"
        return "${baseConfig.getAppId()}/${baseConfig.getAppVersionName()} $okHttpUserAgent"
    }

    private fun getScreenDensity(): String {
        return baseConfig.getApp().resources.getString(R.string.sessions_kit_screen_density)
    }

    private companion object {
        const val URL_PATH_PING = "ping"
        const val HEADER_USER_AGENT = "User-Agent"
        const val HEADER_INSTALLATION_ID = "X-Installation-Id"
        const val HEADER_SERVER_APP_KEY = "X-Server-App-Key"
        const val HEADER_DEVICE_TYPE = "X-Device-Type"
        const val HEADER_APP_VERSION = "X-App-Version"
        const val HEADER_SDK_VERSION = "X-Sdk-Version"
        const val HEADER_OS_NAME = "X-Os-Name"
        const val HEADER_SCREEN_DENSITY = "X-Screen-Density"
    }
}
